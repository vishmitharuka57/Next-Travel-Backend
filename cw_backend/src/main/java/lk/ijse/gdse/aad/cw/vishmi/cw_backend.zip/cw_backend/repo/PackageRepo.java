package lk.ijse.gdse.aad.cw.vishmi.cw_backend.repo;


import lk.ijse.gdse.aad.cw.vishmi.cw_backend.entity.Package;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PackageRepo extends JpaRepository<Package,String> {

}
